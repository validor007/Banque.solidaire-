# Banque Solidaire - Enhanced Flask Banking Platform

## Project Overview
A comprehensive Flask-based banking application with full-featured user management, admin controls, transaction processing, notifications, and security features. The platform supports donations, transfers, credits, and detailed transaction history with export capabilities.

## Recent Changes (October 18, 2025)
- Complete rebuild of banking platform with enhanced features
- Implemented bcrypt password hashing for security
- Added comprehensive notification system (in-app)
- Built admin dashboard with statistics and management tools
- Created transaction history with filtering and CSV export
- Added user profile management with password change
- Implemented audit logging for admin actions
- Created user management panel (suspend/activate accounts)
- Added proper session management and authentication decorators
- Implemented OTP verification system (console-based, email integration pending)

## Project Architecture

### Technology Stack
- **Backend**: Flask 3.1.2 (Python 3.11)
- **Database**: SQLite with proper schema design
- **Security**: bcrypt for password hashing, session-based auth with OTP
- **Frontend**: Jinja2 templates, Bootstrap 5, vanilla JavaScript
- **Additional**: python-dotenv, matplotlib (for future charts), reportlab (for PDFs)

### Database Schema
- `users`: User accounts with balance, status, timestamps
- `donations`: User donation records
- `transfers`: P2P transfers with approval workflow
- `credits`: Admin-issued credits
- `otps`: OTP codes for 2FA
- `notifications`: In-app notification system
- `audit_logs`: Admin action tracking
- `password_resets`: Password reset tokens (prepared for future use)

### Key Features Implemented
1. **User Features**
   - Registration with password hashing
   - Login with OTP verification
   - Dashboard with balance and recent activity
   - Make donations from balance
   - Transfer money to other users
   - View comprehensive transaction history with filters
   - Export transactions to CSV
   - Profile management (update info, change password)
   - In-app notifications with unread badges

2. **Admin Features**
   - Admin dashboard with system statistics
   - Transfer approval/rejection workflow
   - Credit issuance to users
   - User management (view all, suspend/activate)
   - Complete audit log of admin actions
   - Statistics: total users, donations, pending transfers, total balance

3. **Security Features**
   - Bcrypt password hashing
   - Session-based authentication
   - OTP verification for login
   - Login/admin required decorators
   - Account suspension capability
   - Audit trail for admin actions

## User Preferences
- French language interface
- Bootstrap 5 for modern UI
- Print-friendly transaction pages
- CSV export for record keeping

## Pending Integrations
The following integrations are prepared but not yet connected:
1. **Stripe** - For real payment processing (blueprint:flask_stripe available)
2. **SendGrid/Resend** - For email OTP delivery and notifications
3. **Twilio** - For SMS notifications on high-value transfers

## Default Credentials
- **Admin**: admin@bank.com / admin123
- **Test User**: user@test.com / user123

## Running the Application
The Flask server runs on port 5000 (0.0.0.0:5000) with debug mode enabled in development.

## Next Steps
1. Integrate email service for OTP delivery
2. Add Stripe for real payment processing
3. Implement SMS notifications via Twilio
4. Add password reset via email
5. Create data visualization charts for admin dashboard
6. Implement PDF report generation
