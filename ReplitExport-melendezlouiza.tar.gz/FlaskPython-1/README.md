# 🏦 Banque Solidaire - Enhanced Flask Banking Platform

Une plateforme bancaire complète avec gestion des utilisateurs, contrôles administrateur, traitement des transactions, notifications et fonctionnalités de sécurité avancées.

## ✨ Fonctionnalités principales

### Pour les utilisateurs
- ✅ Inscription et connexion sécurisée avec OTP
- 💰 Tableau de bord avec solde et activité récente
- ❤️ Faire des donations depuis le solde
- 💸 Transférer de l'argent à d'autres utilisateurs
- 📊 Historique complet des transactions avec filtres
- 📥 Exporter les transactions en CSV
- 👤 Gestion du profil (mise à jour des infos, changement de mot de passe)
- 🔔 Notifications in-app avec badges non lus

### Pour les administrateurs
- 📈 Tableau de bord avec statistiques système
- ✅ Workflow d'approbation/rejet des transferts
- 💳 Émission de crédits aux utilisateurs
- 👥 Gestion des utilisateurs (visualiser, suspendre/activer)
- 📝 Journal d'audit complet des actions admin
- 📊 Statistiques: total utilisateurs, donations, transferts en attente, solde total

### Sécurité
- 🔐 Hachage des mots de passe avec bcrypt
- 🔑 Authentification basée sur les sessions
- 📱 Vérification OTP pour la connexion
- 🛡️ Décorateurs login/admin requis
- 🚫 Capacité de suspension de compte
- 📋 Piste d'audit pour les actions admin
- ⚡ Protection contre l'injection SQL

## 🚀 Démarrage rapide

### Prérequis
- Python 3.11+
- Flask et dépendances (voir requirements.txt)

### Installation

1. Les dépendances sont déjà installées via le gestionnaire de paquets Replit

2. La variable d'environnement `SESSION_SECRET` est déjà configurée dans Replit Secrets

3. L'application crée automatiquement la base de données au premier lancement

### Lancement de l'application

L'application est configurée pour démarrer automatiquement. Si vous devez la redémarrer manuellement :

```bash
python app.py
```

L'application sera accessible sur `http://localhost:5000` ou via l'URL Replit.

## 👤 Comptes de test

Deux comptes sont préconfigurés pour les tests :

**Administrateur**
- Email: `admin@bank.com`
- Mot de passe: `admin123`
- Solde initial: 10,000 €

**Utilisateur test**
- Email: `user@test.com`
- Mot de passe: `user123`
- Solde initial: 500 €

## 📁 Structure du projet

```
.
├── app.py                      # Application Flask principale
├── database.db                 # Base de données SQLite (créée automatiquement)
├── templates/                  # Templates Jinja2
│   ├── base.html              # Template de base
│   ├── index.html             # Page d'accueil
│   ├── login.html             # Page de connexion
│   ├── register.html          # Page d'inscription
│   ├── verify_otp.html        # Vérification OTP
│   ├── dashboard.html         # Tableau de bord utilisateur
│   ├── transfer.html          # Page de transfert
│   ├── transactions.html      # Historique des transactions
│   ├── profile.html           # Gestion du profil
│   ├── notifications.html     # Page des notifications
│   ├── admin_dashboard.html   # Tableau de bord admin
│   ├── admin_transfers.html   # Gestion des transferts
│   ├── admin_credits.html     # Ajout de crédits
│   ├── admin_users.html       # Gestion des utilisateurs
│   ├── admin_audit.html       # Journal d'audit
│   └── contact.html           # Page de contact
├── static/
│   ├── css/
│   │   └── style.css          # Styles personnalisés
│   └── js/
│       └── main.js            # JavaScript personnalisé
├── requirements.txt           # Dépendances Python
└── README.md                  # Ce fichier
```

## 🗄️ Schéma de la base de données

- **users**: Comptes utilisateurs avec solde, statut, timestamps
- **donations**: Enregistrements de donations
- **transfers**: Transferts P2P avec workflow d'approbation
- **credits**: Crédits émis par l'admin
- **otps**: Codes OTP pour 2FA
- **notifications**: Système de notification in-app
- **audit_logs**: Suivi des actions admin
- **password_resets**: Tokens de réinitialisation de mot de passe (préparé)

## 🔌 Intégrations à venir

Les intégrations suivantes sont préparées mais pas encore connectées :

1. **Stripe** - Pour le traitement des paiements réels
2. **SendGrid/Resend** - Pour la livraison d'OTP par email et notifications
3. **Twilio** - Pour les notifications SMS sur les transferts importants

## 🛠️ Technologies utilisées

- **Backend**: Flask 3.1.2 (Python 3.11)
- **Base de données**: SQLite
- **Sécurité**: bcrypt, sessions Flask
- **Frontend**: Jinja2, Bootstrap 5, JavaScript vanilla
- **Bibliothèques**: python-dotenv, matplotlib, reportlab

## 📝 Notes de sécurité

- ⚠️ Cette application utilise SQLite et est conçue pour le développement/démonstration
- ⚠️ Pour la production, utilisez PostgreSQL ou MySQL
- ⚠️ Assurez-vous que SESSION_SECRET est une chaîne aléatoire cryptographiquement forte
- ⚠️ Les OTP sont actuellement affichés dans la console (intégration email à venir)
- ⚠️ Le mode debug est activé - désactivez-le en production

## 🎨 Interface utilisateur

L'interface est entièrement en français avec :
- Design moderne avec Bootstrap 5
- Icônes Bootstrap Icons
- Pages adaptatives (responsive)
- Pages imprimables pour les transactions
- Alertes et notifications visuelles

## 📄 Licence

Ce projet est à des fins éducatives et de démonstration.

---

**Note**: Cette application est un projet de démonstration. Pour une utilisation en production, des améliorations de sécurité supplémentaires et des tests approfondis sont nécessaires.
