from flask import Flask, render_template, request, redirect, session, flash, jsonify, make_response, send_file
import sqlite3
import bcrypt
import random
import os
import csv
import io
from datetime import datetime, timedelta
from functools import wraps
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)

SESSION_SECRET = os.getenv('SESSION_SECRET')
if not SESSION_SECRET:
    raise RuntimeError(
        "SESSION_SECRET environment variable is required for security. "
        "Please set it to a cryptographically strong random string.")
app.secret_key = SESSION_SECRET


def get_db_connection():
    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_db_connection()

    conn.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            balance REAL DEFAULT 0,
            status TEXT DEFAULT 'active',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ''')

    conn.execute('''
        CREATE TABLE IF NOT EXISTS donations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            amount REAL,
            payment_method TEXT DEFAULT 'balance',
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(user_id) REFERENCES users(id)
        )
    ''')

    conn.execute('''
        CREATE TABLE IF NOT EXISTS transfers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sender_id INTEGER,
            receiver_id INTEGER,
            amount REAL,
            status TEXT DEFAULT 'pending',
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
            approved_at DATETIME,
            FOREIGN KEY(sender_id) REFERENCES users(id),
            FOREIGN KEY(receiver_id) REFERENCES users(id)
        )
    ''')

    conn.execute('''
        CREATE TABLE IF NOT EXISTS credits (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            admin_id INTEGER,
            user_id INTEGER,
            amount REAL,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(user_id) REFERENCES users(id)
        )
    ''')

    conn.execute('''
        CREATE TABLE IF NOT EXISTS otps (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            code TEXT,
            purpose TEXT,
            valid_until DATETIME,
            used INTEGER DEFAULT 0,
            FOREIGN KEY(user_id) REFERENCES users(id)
        )
    ''')

    conn.execute('''
        CREATE TABLE IF NOT EXISTS notifications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            title TEXT,
            message TEXT,
            type TEXT,
            read INTEGER DEFAULT 0,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(user_id) REFERENCES users(id)
        )
    ''')

    conn.execute('''
        CREATE TABLE IF NOT EXISTS audit_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            admin_id INTEGER,
            action TEXT,
            details TEXT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(admin_id) REFERENCES users(id)
        )
    ''')

    conn.execute('''
        CREATE TABLE IF NOT EXISTS password_resets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            token TEXT,
            valid_until DATETIME,
            used INTEGER DEFAULT 0,
            FOREIGN KEY(user_id) REFERENCES users(id)
        )
    ''')

    conn.commit()
    conn.close()


init_db()


def login_required(f):

    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash("Vous devez être connecté pour accéder à cette page")
            return redirect('/login')
        return f(*args, **kwargs)

    return decorated_function


def admin_required(f):

    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'admin' not in session or not session['admin']:
            flash("Accès administrateur requis")
            return redirect('/login')
        return f(*args, **kwargs)

    return decorated_function


def create_notification(user_id, title, message, notif_type='info'):
    conn = get_db_connection()
    conn.execute(
        "INSERT INTO notifications (user_id, title, message, type) VALUES (?, ?, ?, ?)",
        (user_id, title, message, notif_type))
    conn.commit()
    conn.close()


def log_admin_action(admin_id, action, details):
    conn = get_db_connection()
    conn.execute(
        "INSERT INTO audit_logs (admin_id, action, details) VALUES (?, ?, ?)",
        (admin_id, action, details))
    conn.commit()
    conn.close()


def generate_otp(user_id, purpose='login'):
    code = str(random.randint(100000, 999999))
    valid_until = datetime.now() + timedelta(minutes=5)
    conn = get_db_connection()
    conn.execute(
        "INSERT INTO otps (user_id, code, purpose, valid_until) VALUES (?, ?, ?, ?)",
        (user_id, code, purpose, valid_until))
    conn.commit()
    conn.close()
    print(f"[OTP] user_id={user_id} purpose={purpose} code={code}")
    return code


def verify_otp(user_id, code, purpose):
    conn = get_db_connection()
    otp = conn.execute(
        "SELECT * FROM otps WHERE user_id=? AND code=? AND purpose=? AND used=0",
        (user_id, code, purpose)).fetchone()
    if otp:
        try:
            valid_until = datetime.strptime(otp['valid_until'],
                                            '%Y-%m-%d %H:%M:%S.%f')
        except:
            valid_until = datetime.strptime(otp['valid_until'],
                                            '%Y-%m-%d %H:%M:%S')
        if valid_until > datetime.now():
            conn.execute("UPDATE otps SET used=1 WHERE id=?", (otp['id'], ))
            conn.commit()
            conn.close()
            return True
    conn.close()
    return False


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')
        if not (name and email and password):
            flash("Tous les champs sont requis", "error")
            return redirect('/register')

        hashed_password = bcrypt.hashpw(password.encode('utf-8'),
                                        bcrypt.gensalt())

        conn = get_db_connection()
        try:
            conn.execute(
                "INSERT INTO users (name, email, password) VALUES (?, ?, ?)",
                (name, email, hashed_password))
            conn.commit()
            flash("Compte créé avec succès !", "success")
            return redirect('/login')
        except sqlite3.IntegrityError:
            flash("Email déjà utilisé", "error")
        finally:
            conn.close()
    return render_template('register.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')
        conn = get_db_connection()
        user = conn.execute("SELECT * FROM users WHERE email=?",
                            (email, )).fetchone()
        conn.close()

        if user and user['status'] == 'suspended':
            flash("Votre compte a été suspendu. Contactez l'administrateur.",
                  "error")
            return redirect('/login')

        if user and bcrypt.checkpw(password.encode('utf-8'), user['password']):
            session['temp_user_id'] = user['id']
            session[
                'admin'] = True if user['email'] == 'admin@bank.com' else False
            generate_otp(user['id'], 'login')
            flash(
                "OTP généré. Vérifiez la console pour le code (email à venir).",
                "info")
            return redirect('/verify_otp')
        else:
            flash("Email ou mot de passe incorrect", "error")
    return render_template('login.html')


@app.route('/verify_otp', methods=['GET', 'POST'])
def verify_otp_page():
    if 'temp_user_id' not in session:
        return redirect('/login')
    if request.method == 'POST':
        otp_input = request.form.get('otp', '').strip()
        if verify_otp(session['temp_user_id'], otp_input, 'login'):
            session['user_id'] = session.pop('temp_user_id')
            flash("Connexion réussie", "success")
            return redirect('/dashboard')
        else:
            flash("OTP invalide ou expiré", "error")
    return render_template('verify_otp.html')


@app.route('/dashboard')
@login_required
def dashboard():
    conn = get_db_connection()
    user = conn.execute("SELECT * FROM users WHERE id=?",
                        (session['user_id'], )).fetchone()

    recent_donations = conn.execute(
        "SELECT * FROM donations WHERE user_id=? ORDER BY timestamp DESC LIMIT 5",
        (user['id'], )).fetchall()

    unread_count = conn.execute(
        "SELECT COUNT(*) as count FROM notifications WHERE user_id=? AND read=0",
        (user['id'], )).fetchone()['count']

    conn.close()
    return render_template('dashboard.html',
                           user=user,
                           donations=recent_donations,
                           unread_count=unread_count)


@app.route('/donate', methods=['POST'])
@login_required
def donate():
    try:
        amount = float(request.form.get('amount', '0'))
    except:
        flash("Montant invalide", "error")
        return redirect('/dashboard')

    conn = get_db_connection()
    user = conn.execute("SELECT * FROM users WHERE id=?",
                        (session['user_id'], )).fetchone()
    if amount > 0 and user['balance'] >= amount:
        conn.execute("UPDATE users SET balance=balance-? WHERE id=?",
                     (amount, user['id']))
        conn.execute("INSERT INTO donations (user_id, amount) VALUES (?, ?)",
                     (user['id'], amount))
        conn.commit()
        create_notification(user['id'], "Don effectué",
                            f"Vous avez fait un don de {amount} €", "success")
        flash(f"Vous avez fait un don de {amount} € !", "success")
    else:
        flash("Solde insuffisant ou montant invalide", "error")
    conn.close()
    return redirect('/dashboard')


@app.route('/transfer', methods=['GET', 'POST'])
@login_required
def transfer():
    conn = get_db_connection()
    user = conn.execute("SELECT * FROM users WHERE id=?",
                        (session['user_id'], )).fetchone()
    users = conn.execute(
        "SELECT * FROM users WHERE id != ? AND status='active'",
        (user['id'], )).fetchall()

    if request.method == 'POST':
        try:
            receiver_val = request.form.get('receiver')
            if not receiver_val:
                raise ValueError("Receiver ID is required")
            receiver_id = int(receiver_val)
            amount = float(request.form.get('amount', '0'))
        except:
            flash("Données invalides", "error")
            conn.close()
            return redirect('/transfer')

        if amount > 0 and user['balance'] >= amount:
            conn.execute(
                "INSERT INTO transfers (sender_id, receiver_id, amount) VALUES (?, ?, ?)",
                (user['id'], receiver_id, amount))
            conn.commit()
            create_notification(
                user['id'], "Transfert soumis",
                f"Transfert de {amount} € en attente de validation", "info")
            flash("Transfert soumis à validation de l'administrateur", "info")
        else:
            flash("Montant invalide ou solde insuffisant", "error")

    conn.close()
    return render_template('transfer.html', user=user, users=users)


@app.route('/transactions')
@login_required
def transactions():
    conn = get_db_connection()
    user = conn.execute("SELECT * FROM users WHERE id=?",
                        (session['user_id'], )).fetchone()

    filter_type = request.args.get('type', 'all')
    date_from = request.args.get('date_from', '')
    date_to = request.args.get('date_to', '')

    all_transactions = []

    donations = conn.execute(
        "SELECT id, amount, timestamp, 'donation' as type, '' as party FROM donations WHERE user_id=?",
        (user['id'], )).fetchall()

    sent_transfers = conn.execute(
        "SELECT t.id, t.amount, t.timestamp, 'transfer_sent' as type, u.name as party, t.status FROM transfers t JOIN users u ON t.receiver_id=u.id WHERE t.sender_id=?",
        (user['id'], )).fetchall()

    received_transfers = conn.execute(
        "SELECT t.id, t.amount, t.timestamp, 'transfer_received' as type, u.name as party, t.status FROM transfers t JOIN users u ON t.sender_id=u.id WHERE t.receiver_id=?",
        (user['id'], )).fetchall()

    credits = conn.execute(
        "SELECT id, amount, timestamp, 'credit' as type, '' as party FROM credits WHERE user_id=?",
        (user['id'], )).fetchall()

    for d in donations:
        all_transactions.append(dict(d))
    for t in sent_transfers:
        all_transactions.append(dict(t))
    for t in received_transfers:
        all_transactions.append(dict(t))
    for c in credits:
        all_transactions.append(dict(c))

    all_transactions.sort(key=lambda x: x['timestamp'], reverse=True)

    if filter_type != 'all':
        all_transactions = [
            t for t in all_transactions if t['type'] == filter_type
        ]

    if date_from:
        all_transactions = [
            t for t in all_transactions if t['timestamp'] >= date_from
        ]
    if date_to:
        all_transactions = [
            t for t in all_transactions
            if t['timestamp'] <= date_to + ' 23:59:59'
        ]

    conn.close()
    return render_template('transactions.html',
                           user=user,
                           transactions=all_transactions)


@app.route('/export_transactions')
@login_required
def export_transactions():
    conn = get_db_connection()
    user = conn.execute("SELECT * FROM users WHERE id=?",
                        (session['user_id'], )).fetchone()

    all_transactions = []

    donations = conn.execute(
        "SELECT amount, timestamp, 'Donation' as type, '' as party FROM donations WHERE user_id=?",
        (user['id'], )).fetchall()

    sent_transfers = conn.execute(
        "SELECT t.amount, t.timestamp, 'Transfert envoyé' as type, u.name as party FROM transfers t JOIN users u ON t.receiver_id=u.id WHERE t.sender_id=? AND t.status='approved'",
        (user['id'], )).fetchall()

    received_transfers = conn.execute(
        "SELECT t.amount, t.timestamp, 'Transfert reçu' as type, u.name as party FROM transfers t JOIN users u ON t.sender_id=u.id WHERE t.receiver_id=? AND t.status='approved'",
        (user['id'], )).fetchall()

    credits = conn.execute(
        "SELECT amount, timestamp, 'Crédit' as type, 'Administrateur' as party FROM credits WHERE user_id=?",
        (user['id'], )).fetchall()

    for d in donations:
        all_transactions.append(dict(d))
    for t in sent_transfers:
        all_transactions.append(dict(t))
    for t in received_transfers:
        all_transactions.append(dict(t))
    for c in credits:
        all_transactions.append(dict(c))

    all_transactions.sort(key=lambda x: x['timestamp'], reverse=True)

    si = io.StringIO()
    writer = csv.writer(si)
    writer.writerow(['Date', 'Type', 'Montant', 'Partie'])

    for t in all_transactions:
        writer.writerow(
            [t['timestamp'], t['type'], f"{t['amount']} €", t['party']])

    output = io.BytesIO()
    output.write(si.getvalue().encode('utf-8'))
    output.seek(0)

    conn.close()

    return send_file(
        output,
        mimetype='text/csv',
        as_attachment=True,
        download_name=
        f'transactions_{user["name"]}_{datetime.now().strftime("%Y%m%d")}.csv')


@app.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    conn = get_db_connection()
    user = conn.execute("SELECT * FROM users WHERE id=?",
                        (session['user_id'], )).fetchone()

    if request.method == 'POST':
        action = request.form.get('action')

        if action == 'update_info':
            name = request.form.get('name', '').strip()
            email = request.form.get('email', '').strip().lower()

            if name and email:
                try:
                    conn.execute("UPDATE users SET name=?, email=? WHERE id=?",
                                 (name, email, user['id']))
                    conn.commit()
                    flash("Informations mises à jour avec succès", "success")
                except sqlite3.IntegrityError:
                    flash("Cet email est déjà utilisé", "error")

        elif action == 'update_password':
            current_password = request.form.get('current_password', '')
            new_password = request.form.get('new_password', '')
            confirm_password = request.form.get('confirm_password', '')

            if bcrypt.checkpw(current_password.encode('utf-8'),
                              user['password']):
                if new_password == confirm_password and len(new_password) >= 6:
                    hashed_password = bcrypt.hashpw(
                        new_password.encode('utf-8'), bcrypt.gensalt())
                    conn.execute("UPDATE users SET password=? WHERE id=?",
                                 (hashed_password, user['id']))
                    conn.commit()
                    flash("Mot de passe mis à jour avec succès", "success")
                else:
                    flash(
                        "Les mots de passe ne correspondent pas ou sont trop courts",
                        "error")
            else:
                flash("Mot de passe actuel incorrect", "error")

        user = conn.execute("SELECT * FROM users WHERE id=?",
                            (session['user_id'], )).fetchone()

    conn.close()
    return render_template('profile.html', user=user)


@app.route('/notifications')
@login_required
def notifications():
    conn = get_db_connection()
    user = conn.execute("SELECT * FROM users WHERE id=?",
                        (session['user_id'], )).fetchone()
    notifs = conn.execute(
        "SELECT * FROM notifications WHERE user_id=? ORDER BY timestamp DESC",
        (user['id'], )).fetchall()

    conn.execute("UPDATE notifications SET read=1 WHERE user_id=?",
                 (user['id'], ))
    conn.commit()
    conn.close()

    return render_template('notifications.html',
                           user=user,
                           notifications=notifs)


@app.route('/admin/dashboard')
@admin_required
def admin_dashboard():
    conn = get_db_connection()

    total_users = conn.execute(
        "SELECT COUNT(*) as count FROM users").fetchone()['count']
    total_donations = conn.execute(
        "SELECT COALESCE(SUM(amount), 0) as total FROM donations").fetchone(
        )['total']
    pending_transfers = conn.execute(
        "SELECT COUNT(*) as count FROM transfers WHERE status='pending'"
    ).fetchone()['count']
    total_balance = conn.execute(
        "SELECT COALESCE(SUM(balance), 0) as total FROM users").fetchone(
        )['total']

    recent_users = conn.execute(
        "SELECT * FROM users ORDER BY created_at DESC LIMIT 5").fetchall()

    conn.close()
    return render_template('admin_dashboard.html',
                           total_users=total_users,
                           total_donations=total_donations,
                           pending_transfers=pending_transfers,
                           total_balance=total_balance,
                           recent_users=recent_users)


@app.route('/admin/transfers', methods=['GET', 'POST'])
@admin_required
def admin_transfers():
    conn = get_db_connection()
    transfers = conn.execute('''
        SELECT t.*, u1.name as sender_name, u2.name as receiver_name
        FROM transfers t
        JOIN users u1 ON t.sender_id=u1.id
        JOIN users u2 ON t.receiver_id=u2.id
        WHERE t.status='pending'
        ORDER BY t.timestamp ASC
    ''').fetchall()

    if request.method == 'POST':
        try:
            transfer_id_val = request.form.get('transfer_id')
            if not transfer_id_val:
                raise ValueError("Transfer ID is required")
            transfer_id = int(transfer_id_val)
        except:
            flash("ID transfert invalide", "error")
            conn.close()
            return redirect('/admin/transfers')

        action = request.form.get('action')
        transfer = conn.execute("SELECT * FROM transfers WHERE id=?",
                                (transfer_id, )).fetchone()

        if not transfer:
            flash("Transfert introuvable", "error")
            conn.close()
            return redirect('/admin/transfers')

        if action == 'approve':
            conn.execute("UPDATE users SET balance = balance - ? WHERE id=?",
                         (transfer['amount'], transfer['sender_id']))
            conn.execute("UPDATE users SET balance = balance + ? WHERE id=?",
                         (transfer['amount'], transfer['receiver_id']))
            conn.execute(
                "UPDATE transfers SET status='approved', approved_at=? WHERE id=?",
                (datetime.now(), transfer_id))
            conn.commit()

            create_notification(
                transfer['sender_id'], "Transfert approuvé",
                f"Votre transfert de {transfer['amount']} € a été approuvé",
                "success")
            create_notification(transfer['receiver_id'], "Transfert reçu",
                                f"Vous avez reçu {transfer['amount']} €",
                                "success")

            log_admin_action(
                session['user_id'], "Transfert approuvé",
                f"Transfer ID {transfer_id} pour {transfer['amount']} €")
            flash("Transfert approuvé", "success")
        else:
            conn.execute("UPDATE transfers SET status='rejected' WHERE id=?",
                         (transfer_id, ))
            conn.commit()

            create_notification(
                transfer['sender_id'], "Transfert rejeté",
                f"Votre transfert de {transfer['amount']} € a été rejeté",
                "warning")

            log_admin_action(
                session['user_id'], "Transfert rejeté",
                f"Transfer ID {transfer_id} pour {transfer['amount']} €")
            flash("Transfert rejeté", "info")

    conn.close()
    return render_template('admin_transfers.html', transfers=transfers)


@app.route('/admin/credits', methods=['GET', 'POST'])
@admin_required
def admin_credits():
    conn = get_db_connection()
    users = conn.execute(
        "SELECT * FROM users WHERE status='active'").fetchall()

    if request.method == 'POST':
        try:
            user_id_val = request.form.get('user_id')
            if not user_id_val:
                raise ValueError("User ID is required")
            user_id = int(user_id_val)
            amount = float(request.form.get('amount', '0'))
        except:
            flash("Données invalides", "error")
            conn.close()
            return redirect('/admin/credits')

        if amount > 0:
            conn.execute("UPDATE users SET balance = balance + ? WHERE id=?",
                         (amount, user_id))
            conn.execute(
                "INSERT INTO credits (admin_id, user_id, amount) VALUES (?, ?, ?)",
                (session['user_id'], user_id, amount))
            conn.commit()

            create_notification(user_id, "Crédit reçu",
                                f"Vous avez reçu un crédit de {amount} €",
                                "success")
            log_admin_action(session['user_id'], "Crédit ajouté",
                             f"Crédit de {amount} € pour user ID {user_id}")

            flash(f"{amount} € crédités avec succès !", "success")
        else:
            flash("Montant invalide", "error")

    conn.close()
    return render_template('admin_credits.html', users=users)


@app.route('/admin/users', methods=['GET', 'POST'])
@admin_required
def admin_users():
    conn = get_db_connection()

    if request.method == 'POST':
        user_id_val = request.form.get('user_id')
        if user_id_val:
            user_id = int(user_id_val)
        else:
            flash("ID utilisateur invalide", "error")
            conn.close()
            return redirect('/admin/users')
        action = request.form.get('action')

        user = conn.execute("SELECT * FROM users WHERE id=?",
                            (user_id, )).fetchone()

        if action == 'suspend':
            conn.execute("UPDATE users SET status='suspended' WHERE id=?",
                         (user_id, ))
            conn.commit()
            create_notification(user_id, "Compte suspendu",
                                "Votre compte a été suspendu", "warning")
            log_admin_action(session['user_id'], "Compte suspendu",
                             f"User ID {user_id} - {user['email']}")
            flash("Compte suspendu", "success")
        elif action == 'activate':
            conn.execute("UPDATE users SET status='active' WHERE id=?",
                         (user_id, ))
            conn.commit()
            create_notification(user_id, "Compte activé",
                                "Votre compte a été réactivé", "success")
            log_admin_action(session['user_id'], "Compte activé",
                             f"User ID {user_id} - {user['email']}")
            flash("Compte activé", "success")

    users = conn.execute(
        "SELECT * FROM users ORDER BY created_at DESC").fetchall()
    conn.close()
    return render_template('admin_users.html', users=users)


@app.route('/admin/audit')
@admin_required
def admin_audit():
    conn = get_db_connection()
    logs = conn.execute('''
        SELECT a.*, u.name as admin_name 
        FROM audit_logs a 
        JOIN users u ON a.admin_id=u.id 
        ORDER BY a.timestamp DESC 
        LIMIT 100
    ''').fetchall()
    conn.close()
    return render_template('admin_audit.html', logs=logs)


@app.route('/contact', methods=['GET', 'POST'])
def contact():
    if request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email')
        message = request.form.get('message')
        print(f"[CONTACT] De: {name} <{email}> — {message}")
        flash("Votre message a été envoyé avec succès !", "success")
        return redirect('/contact')
    return render_template('contact.html')


@app.route('/logout')
def logout():
    session.clear()
    flash("Déconnexion réussie", "info")
    return redirect('/')


if __name__ == "__main__":
    app.run(host='0.0.0.0', port=5000, debug=True)
