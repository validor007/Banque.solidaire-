bank-donation/
│
├─ app.py
├─ database.db  (sera créé automatiquement)
├─ templates/
│   ├─ index.html
│   ├─ register.html
│   ├─ login.html
│   ├─ verify_otp.html
│   ├─ dashboard.html
│   ├─ transfer.html
│   ├─ admin_transfers.html
│   └─ admin_credits.html
└─ static/
    └─ style.css
